export default function orderTemplate({ order, shop = { name: 'Fullstock' } }) {
  const date = order?.createdAt ? new Date(order.createdAt).toLocaleString() : '';
  const rows = (order?.items || []).map(it => `
    <tr>
      <td style="padding:6px 8px;border-bottom:1px solid #eee">
        <div style="font-weight:600">${it.name || it.product?.name || 'Producto'}</div>
        ${it.variant ? `<div style="opacity:.75;font-size:12px">Variante: ${it.variant}</div>` : ''}
      </td>
      <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right">x${it.qty || 1}</td>
      <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right">$${Number(it.price || it.product?.price || 0).toFixed(2)}</td>
    </tr>
  `).join('');

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Confirmación de orden</title>
</head>
<body style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#f7f7f7;padding:24px">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center">
        <table role="presentation" width="640" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:10px;overflow:hidden">
          <tr>
            <td style="background:#111;color:#fff;padding:16px 20px;font-size:18px;font-weight:700">${shop.name}</td>
          </tr>
          <tr><td style="padding:20px">
            <h1 style="margin:0 0 12px;font-size:20px">¡Gracias por tu compra!</h1>
            <p style="margin:0 0 16px">Confirmación de tu orden:</p>
            <p style="margin:0 0 4px"><strong>Orden:</strong> ${order?._id || '-'}</p>
            <p style="margin:0 0 16px"><strong>Fecha:</strong> ${date}</p>

            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:12px 0">
              <thead>
                <tr>
                  <th style="text-align:left;padding:6px 8px;border-bottom:2px solid #111">Producto</th>
                  <th style="text-align:right;padding:6px 8px;border-bottom:2px solid #111">Cant.</th>
                  <th style="text-align:right;padding:6px 0;border-bottom:2px solid #111">Precio</th>
                </tr>
              </thead>
              <tbody>
                ${rows || '<tr><td colspan="3" style="padding:12px 0">Sin items</td></tr>'}
              </tbody>
            </table>

            <div style="text-align:right">
              <div><strong>Subtotal:</strong> $${Number(order?.subtotal || 0).toFixed(2)}</div>
              ${'shipping' in (order||{}) ? `<div><strong>Envío:</strong> $${Number(order.shipping || 0).toFixed(2)}</div>` : ''}
              <div style="font-size:18px;margin-top:6px"><strong>Total:</strong> $${Number(order?.total || order?.amount || 0).toFixed(2)}</div>
            </div>

            <p style="margin:20px 0 0">Podés ver tu orden aquí:</p>
            <p style="margin:8px 0 0"><a href="${process.env.PUBLIC_BASE_URL || 'http://localhost:5173'}/order/${order?._id}" style="color:#111">Ver mi pedido</a></p>
          </td></tr>
          <tr>
            <td style="background:#f1f1f1;color:#333;padding:12px 20px;font-size:12px">Este es un correo automático. Si no reconocés esta compra, escribinos a ${process.env.MAIL_RECEIVER || ''}.</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}
