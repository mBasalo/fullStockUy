// client/src/pages/ProductList.jsx
import React from "react";

export default function ProductList() {
  return (
    <main className="p-6">
      <h1 className="text-3xl font-bold mb-4">Todos los productos</h1>
      <p>Esta página mostrará todos los productos disponibles.</p>
    </main>
  );
}

