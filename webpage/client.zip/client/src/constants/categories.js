export const CATEGORIES = [
  { key: 'motos', label: 'Motos' },
  { key: 'bicicletas', label: 'Bicicletas' },
  { key: 'monopatines', label: 'Monopatines' },
  { key: 'accesorios', label: 'Accesorios' },
];
